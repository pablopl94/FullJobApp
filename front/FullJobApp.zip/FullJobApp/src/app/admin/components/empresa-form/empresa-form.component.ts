import { Component } from '@angular/core';

@Component({
  selector: 'app-empresa-form',
  imports: [],
  templateUrl: './empresa-form.component.html',
  styleUrl: './empresa-form.component.css'
})
export class EmpresaFormComponent {

}
