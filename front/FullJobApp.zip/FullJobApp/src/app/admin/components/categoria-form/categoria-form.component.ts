import { Component } from '@angular/core';
import { ICategoria } from '../../../core/interfaces/Icategoria';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CategoriasService } from '../../../core/services/categorias.service';

@Component({
  selector: 'app-categoria-form',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule],
  templateUrl: './categoria-form.component.html',
  styleUrl: './categoria-form.component.css',
})
export class CategoriaFormComponent {
  categoriaForm: FormGroup;
  submitted = false;

  constructor(
    private fb: FormBuilder,
    private categoriasService: CategoriasService,
    private router: Router
  ) {
    this.categoriaForm = this.fb.group({
      nombre: ['', Validators.required],
      descripcion: ['', Validators.required],
    });
  }

  onSubmit(): void {
    this.submitted = true;

    if (this.categoriaForm.invalid) return;

    const nuevaCategoria: ICategoria = this.categoriaForm.value;

    this.categoriasService.createCategoria(nuevaCategoria).subscribe({
      next: () => {
        alert('¡Categoría creada correctamente!');
        this.router.navigate(['/admin/categorias']);
      },
      error: (err) => {
        console.error(err);
        alert('Error al crear la categoría');
      },
    });
  }
}
