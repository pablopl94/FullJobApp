import { Component } from '@angular/core';

@Component({
  selector: 'app-botones-vacante-empresa',
  imports: [],
  templateUrl: './botones-vacante-empresa.component.html',
  styleUrl: './botones-vacante-empresa.component.css'
})
export class BotonesVacanteEmpresaComponent {

}
