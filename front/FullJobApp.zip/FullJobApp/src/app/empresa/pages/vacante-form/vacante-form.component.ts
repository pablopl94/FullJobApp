import { Component } from '@angular/core';

@Component({
  selector: 'app-vacante-form',
  imports: [],
  templateUrl: './vacante-form.component.html',
  styleUrl: './vacante-form.component.css'
})
export class VacanteFormComponent {

}
