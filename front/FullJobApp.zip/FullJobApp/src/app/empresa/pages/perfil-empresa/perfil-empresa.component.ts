import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-empresa',
  imports: [],
  templateUrl: './perfil-empresa.component.html',
  styleUrl: './perfil-empresa.component.css'
})
export class PerfilEmpresaComponent {

}
