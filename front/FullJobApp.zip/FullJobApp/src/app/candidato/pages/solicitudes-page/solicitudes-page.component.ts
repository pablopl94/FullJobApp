import { Component } from '@angular/core';

@Component({
  selector: 'app-solicitudes-page',
  imports: [],
  templateUrl: './solicitudes-page.component.html',
  styleUrl: './solicitudes-page.component.css'
})
export class SolicitudesPageComponent {

}
