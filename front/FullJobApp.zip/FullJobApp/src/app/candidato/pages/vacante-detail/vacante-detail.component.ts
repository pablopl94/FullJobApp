import { Component } from '@angular/core';

@Component({
  selector: 'app-vacante-detail',
  imports: [],
  templateUrl: './vacante-detail.component.html',
  styleUrl: './vacante-detail.component.css'
})
export class VacanteDetailComponent {

}
