import { Component } from '@angular/core';

@Component({
  selector: 'app-vacantes-page',
  imports: [],
  templateUrl: './vacantes-page.component.html',
  styleUrl: './vacantes-page.component.css'
})
export class VacantesPageComponent {

}
