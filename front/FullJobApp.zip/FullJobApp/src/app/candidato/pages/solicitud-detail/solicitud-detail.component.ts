import { Component } from '@angular/core';

@Component({
  selector: 'app-solicitud-detail',
  imports: [],
  templateUrl: './solicitud-detail.component.html',
  styleUrl: './solicitud-detail.component.css'
})
export class SolicitudDetailComponent {

}
