import { Component } from '@angular/core';

@Component({
  selector: 'app-vacante-card',
  imports: [],
  templateUrl: './vacante-card.component.html',
  styleUrl: './vacante-card.component.css'
})
export class VacanteCardComponent {

}
