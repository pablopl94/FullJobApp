import { Component } from '@angular/core';

@Component({
  selector: 'app-solicitud-card',
  imports: [],
  templateUrl: './solicitud-card.component.html',
  styleUrl: './solicitud-card.component.css'
})
export class SolicitudCardComponent {

}
