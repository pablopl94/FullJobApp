import { Component } from '@angular/core';

@Component({
  selector: 'app-postular-form',
  imports: [],
  templateUrl: './postular-form.component.html',
  styleUrl: './postular-form.component.css'
})
export class PostularFormComponent {

}
