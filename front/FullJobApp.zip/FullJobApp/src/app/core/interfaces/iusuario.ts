export interface IUsuario {    
  token: string;
  email: string;
  nombre: string;
  apellidos: string;
  rol: string;
  enabled: number;
  fechaRegistro: string;
  }
  