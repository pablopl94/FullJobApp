export interface ICategoria {
  id: number;
  nombre: string;
  descripcion: string;
}
