// import { Component } from '@angular/core';

// @Component({
//   standalone: true,
//   selector: 'app-register-page',
//   imports: [],
//   templateUrl: './register-page.component.html',
//   styleUrl: './register-page.component.css'
// })
// export default class RegisterPageComponent {

// }
