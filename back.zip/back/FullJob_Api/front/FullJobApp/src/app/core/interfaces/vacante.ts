export interface Vacante {
}
