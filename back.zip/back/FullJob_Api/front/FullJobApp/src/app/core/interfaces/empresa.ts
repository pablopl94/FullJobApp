export interface Empresa {
}
