export interface Categoria {
}
