import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class VacantesService {

  constructor() { }
}
