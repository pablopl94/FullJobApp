export interface Solicitud {
}
