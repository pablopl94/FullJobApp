package com.fulljob.api.models.entities;

public enum TipoDeContrato {
	
    INDEFINIDO,
    TEMPORAL,
    AUTONOMO,
    PRACTICAS
}
