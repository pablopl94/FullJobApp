package com.fulljob.api.models.entities;

public enum EstadoVacante {
	CREADA,
	CANCELADA,
	ASIGNADA
}
