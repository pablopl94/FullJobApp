package com.fulljob.api.services;

import com.fulljob.api.models.entities.Categoria;

public interface ICategoriaService extends IGenericCrud<Categoria, Integer> {

}
