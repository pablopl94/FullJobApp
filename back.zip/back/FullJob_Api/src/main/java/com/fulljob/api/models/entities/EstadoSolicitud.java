package com.fulljob.api.models.entities;

public enum EstadoSolicitud {
    PRESENTADA,    // 0: Solicitud presentada
    ADJUDICADA    // 1: Solicitud adjudicada a una vacante
}
