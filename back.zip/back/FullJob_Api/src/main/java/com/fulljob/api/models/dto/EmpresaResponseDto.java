package com.fulljob.api.models.dto;

import lombok.Data;

@Data
public class EmpresaResponseDto {
	
    private String cif;

    private String nombreEmpresa;

    private String direccionFiscal;

    private String pais;

   
}
