package com.fulljob.api.services;

import com.fulljob.api.models.entities.Empresa;


public interface IEmpresaService extends IGenericCrud<Empresa, Integer>{
	
}
